package io.dbasic.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import io.dbasic.model.DatabaseConnection;
import io.dbasic.utils.AESUtil;

@Service
public class DatabaseConnectionExcelService {
	
	private static final String FILE_PATH = "src/main/resources/data/db_credentials.xlsx";

	public List<DatabaseConnection> readConnections() {
	    System.out.println("📘 Reading Excel file...");
	    List<DatabaseConnection> list = new ArrayList<>();

	    try {
	        File file = new File(FILE_PATH);
	        System.out.println("🔍 Looking for Excel file at: " + file.getAbsolutePath());

	        try (InputStream fis = new FileInputStream(file);
	             Workbook workbook = new XSSFWorkbook(fis)) {

	            Sheet sheet = workbook.getSheetAt(0);

	            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
	                Row row = sheet.getRow(i);
	                if (row == null || row.getCell(0) == null) continue;

	                DatabaseConnection conn = new DatabaseConnection();
	                conn.setEnvName(row.getCell(0).getStringCellValue());
	                conn.setDbType(row.getCell(1).getStringCellValue());
	                conn.setHost(row.getCell(2).getStringCellValue());
	                conn.setPort((int) row.getCell(3).getNumericCellValue());
	                conn.setDbName(row.getCell(4).getStringCellValue());
	                conn.setUsername(row.getCell(5).getStringCellValue());

	                String encryptedPassword = row.getCell(6).getStringCellValue();
	                System.out.println("encryptedPassword"+encryptedPassword);
	                conn.setPassword(encryptedPassword);
	                System.out.println("decryption "+conn.getPassword());
	                conn.setSchemaName(row.getCell(7).getStringCellValue());

	                list.add(conn);
	            }
	        }

	    } catch (Exception e) {
	        throw new RuntimeException("Failed to read DB credentials from Excel", e);
	    }

	    return list;
	}


	    public void writeConnections(List<DatabaseConnection> connections) {
	        try (Workbook workbook = new XSSFWorkbook()) {
	            Sheet sheet = workbook.createSheet("DB Connections");

	            // Write header
	            Row header = sheet.createRow(0);
	            header.createCell(0).setCellValue("Env Name");
	            header.createCell(1).setCellValue("DB Type");
	            header.createCell(2).setCellValue("Host");
	            header.createCell(3).setCellValue("Port");
	            header.createCell(4).setCellValue("DB Name");
	            header.createCell(5).setCellValue("Username");
	            header.createCell(6).setCellValue("Password (Encrypted)");
	            header.createCell(7).setCellValue("Schema Name");

	            // Write each connection
	            int rowNum = 1;
	            for (DatabaseConnection conn : connections) {
	                Row row = sheet.createRow(rowNum++);
	                row.createCell(0).setCellValue(conn.getEnvName());
	                row.createCell(1).setCellValue(conn.getDbType());
	                row.createCell(2).setCellValue(conn.getHost());
	                row.createCell(3).setCellValue(conn.getPort());
	                row.createCell(4).setCellValue(conn.getDbName());
	                row.createCell(5).setCellValue(conn.getUsername());
	                row.createCell(6).setCellValue(AESUtil.encrypt(conn.getPassword()));
	                row.createCell(7).setCellValue(conn.getSchemaName());
	            }

	            try (FileOutputStream fos = new FileOutputStream(FILE_PATH)) {
	                workbook.write(fos);
	            }

	        } catch (Exception e) {
	            throw new RuntimeException("Failed to write DB credentials to Excel", e);
	        }
	    }
}
