package io.dbasic.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.dbasic.dto.ScriptComparisonResult;
import io.dbasic.service.ScriptComparisonService;

@RestController
@RequestMapping("/api/compare")
public class ScriptComparisonController {

	@Autowired
	private ScriptComparisonService scriptComparisonService;

	@GetMapping("/{sourceEnv}/{targetEnv}/{objectType}")
	public List<ScriptComparisonResult> compare(@PathVariable String sourceEnv, @PathVariable String targetEnv,
			@PathVariable String objectType) {
		return scriptComparisonService.compareEnvScripts(sourceEnv, targetEnv, objectType);
	}

	// New API for full environment comparison
	@GetMapping("/all/{sourceEnv}/{targetEnv}")
	public Map<String, List<ScriptComparisonResult>> compareAllScripts(@PathVariable String sourceEnv,
			@PathVariable String targetEnv) {
		return scriptComparisonService.compareAllEnvScripts(sourceEnv, targetEnv);
	}

}
