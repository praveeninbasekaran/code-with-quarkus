package io.dbasic.service;

import java.io.File;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;

import io.dbasic.model.DatabaseConnection;
import io.dbasic.utils.AESUtil;

@Service
public class ScriptExportService {

	private static final String BASE_PATH = "src/main/resources/generated-scripts/";

	@Autowired
	private DatabaseConnectionExcelService excelService;


	 public String exportSchemaScripts(String envName) {
	        try {
	            List<DatabaseConnection> connections = excelService.readConnections();
	            DatabaseConnection connInfo = connections.stream()
	                    .filter(c -> c.getEnvName().equalsIgnoreCase(envName))
	                    .findFirst()
	                    .orElseThrow(() -> new RuntimeException("No DB config for env: " + envName));

	            String envPath = BASE_PATH + envName.toLowerCase();
	            new File(envPath + "/tables").mkdirs();
	            new File(envPath + "/sequences").mkdirs();
	            new File(envPath + "/triggers").mkdirs();
	            new File(envPath + "/functions").mkdirs();

	            DataSource dataSource = getDataSource(connInfo);
	            exportTableScripts(dataSource, connInfo, envPath);
	            exportSequenceScripts(dataSource, connInfo, envPath);
	            exportTriggerScripts(dataSource, connInfo, envPath);
	            exportFunctionScripts(dataSource, connInfo, envPath);
	            exportViewScripts(dataSource, connInfo, envPath);
	            exportIndexScripts(dataSource, connInfo, envPath);
	            exportConstraintScripts(dataSource, connInfo, envPath);
	            return "Scripts exported to: " + envPath;
	        } catch (Exception e) {
	            throw new RuntimeException("❌ Failed to export schema scripts", e);
	        }
	    }

	    private DataSource getDataSource(DatabaseConnection connInfo) {
	        DriverManagerDataSource dataSource = new DriverManagerDataSource();
	        dataSource.setDriverClassName("org.postgresql.Driver");
	        dataSource.setUrl("jdbc:postgresql://" + connInfo.getHost() + ":" + connInfo.getPort() + "/" + connInfo.getDbName());
	        dataSource.setUsername(connInfo.getUsername());
	        dataSource.setPassword(AESUtil.decrypt(connInfo.getPassword()));
	        return dataSource;
	    }

	    private void exportTableScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        try (Connection conn = dataSource.getConnection()) {
	            String tableQuery = "SELECT table_name FROM information_schema.tables WHERE table_schema = ? AND table_type='BASE TABLE'";
	            try (PreparedStatement stmt = conn.prepareStatement(tableQuery)) {
	                stmt.setString(1, connInfo.getSchemaName());
	                ResultSet rs = stmt.executeQuery();
	                while (rs.next()) {
	                    String tableName = rs.getString("table_name");
	                    generateTableDDL(conn, connInfo.getSchemaName(), tableName, envPath + "/tables/" + tableName + ".sql");
	                }
	            }
	        }
	    }

	    private void generateTableDDL(Connection conn, String schema, String tableName, String outputPath) throws Exception {
	        StringBuilder ddl = new StringBuilder("CREATE TABLE IF NOT EXISTS " + schema + "." + tableName + " (\n");

	        String colQuery = "SELECT column_name, data_type, is_nullable, column_default " +
	                "FROM information_schema.columns " +
	                "WHERE table_schema = ? AND table_name = ? ORDER BY ordinal_position";

	        try (PreparedStatement stmt = conn.prepareStatement(colQuery)) {
	            stmt.setString(1, schema);
	            stmt.setString(2, tableName);
	            ResultSet rs = stmt.executeQuery();

	            boolean first = true;
	            while (rs.next()) {
	                if (!first) ddl.append(",\n");
	                first = false;
	                ddl.append("  ").append(rs.getString("column_name"))
	                    .append(" ").append(rs.getString("data_type"));

	                if (rs.getString("column_default") != null)
	                    ddl.append(" DEFAULT ").append(rs.getString("column_default"));
	                if ("NO".equalsIgnoreCase(rs.getString("is_nullable")))
	                    ddl.append(" NOT NULL");
	            }
	        }

	        // Constraints: Primary key
	        String pkQuery = "SELECT kcu.column_name " +
	                "FROM information_schema.table_constraints tc " +
	                "JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name " +
	                "WHERE tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = ? AND tc.table_name = ?";
	        try (PreparedStatement stmt = conn.prepareStatement(pkQuery)) {
	            stmt.setString(1, schema);
	            stmt.setString(2, tableName);
	            ResultSet rs = stmt.executeQuery();

	            StringBuilder pk = new StringBuilder();
	            while (rs.next()) {
	                if (pk.length() > 0) pk.append(", ");
	                pk.append(rs.getString("column_name"));
	            }
	            if (pk.length() > 0) {
	                ddl.append(",\n  CONSTRAINT ").append(tableName).append("_pkey PRIMARY KEY (").append(pk).append(")");
	            }
	        }

	        // Constraints: Foreign keys
	        String fkQuery = "SELECT tc.constraint_name, kcu.column_name, " +
	                "ccu.table_name AS foreign_table_name, ccu.column_name AS foreign_column_name " +
	                "FROM information_schema.table_constraints tc " +
	                "JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name " +
	                "JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name " +
	                "WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = ? AND tc.table_name = ?";

	        try (PreparedStatement stmt = conn.prepareStatement(fkQuery)) {
	            stmt.setString(1, schema);
	            stmt.setString(2, tableName);
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                ddl.append(",\n  CONSTRAINT ").append(rs.getString("constraint_name"))
	                    .append(" FOREIGN KEY (").append(rs.getString("column_name")).append(")")
	                    .append(" REFERENCES ").append(rs.getString("foreign_table_name"))
	                    .append(" (").append(rs.getString("foreign_column_name")).append(")");
	            }
	        }

	        ddl.append("\n);");

	        try (FileWriter writer = new FileWriter(outputPath)) {
	            writer.write(ddl.toString());
	        }
	    }

	    private void exportSequenceScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String query = "SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = ?";
	        try (Connection conn = dataSource.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {

	            stmt.setString(1, connInfo.getSchemaName());
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                String sequenceName = rs.getString("sequence_name");
	                String ddl = "CREATE SEQUENCE " + connInfo.getSchemaName() + "." + sequenceName + ";";
	                try (FileWriter writer = new FileWriter(envPath + "/sequences/" + sequenceName + ".sql")) {
	                    writer.write(ddl);
	                }
	            }
	        }
	    }

	    private void exportTriggerScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String triggerQuery = """
	            SELECT 
	                tg.tgname AS trigger_name,
	                event_manipulation,
	                action_timing,
	                event_object_table,
	                action_statement,
	                tg.tgfoid AS function_oid
	            FROM information_schema.triggers t
	            JOIN pg_trigger tg ON tg.tgname = t.trigger_name
	            WHERE trigger_schema = ?
	              AND NOT tg.tgisinternal
	        """;

	        try (Connection conn = dataSource.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(triggerQuery)) {

	            stmt.setString(1, connInfo.getSchemaName());
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                String triggerName = rs.getString("trigger_name");
	                String table = rs.getString("event_object_table");
	                String timing = rs.getString("action_timing");
	                String event = rs.getString("event_manipulation");
	                String statement = rs.getString("action_statement");
	                long funcOid = rs.getLong("function_oid");

	                // Trigger DDL
	                String triggerDDL = "CREATE TRIGGER " + triggerName + "\n"
	                        + timing + " " + event + " ON " + table + "\n"
	                        + "FOR EACH ROW\n" + statement + ";";

	                try (FileWriter writer = new FileWriter(envPath + "/triggers/" + triggerName + ".sql")) {
	                    writer.write("-- Trigger\n");
	                    writer.write(triggerDDL + "\n\n");

	                    // Trigger function definition
	                    String functionDDL = getTriggerFunctionDDL(conn, funcOid);
	                    writer.write("-- Function used in trigger\n");
	                    writer.write(functionDDL);
	                }
	            }
	        }
	    }
	    
	    private String getTriggerFunctionDDL(Connection conn, long funcOid) throws SQLException {
	        String query = "SELECT pg_get_functiondef(?) AS definition";
	        try (PreparedStatement stmt = conn.prepareStatement(query)) {
	            stmt.setLong(1, funcOid);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                return rs.getString("definition");
	            }
	        }
	        return "-- Trigger function definition not found";
	    }


	    private void exportFunctionScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String query = """
	            SELECT 
	                n.nspname as schema,
	                p.proname as function_name,
	                l.lanname as language,
	                pg_get_functiondef(p.oid) as definition
	            FROM pg_proc p
	            JOIN pg_namespace n ON p.pronamespace = n.oid
	            JOIN pg_language l ON p.prolang = l.oid
	            WHERE n.nspname = ?
	            AND pg_get_function_result(p.oid) = 'trigger'
	        """;

	        try (Connection conn = dataSource.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {

	            stmt.setString(1, connInfo.getSchemaName());
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                String functionName = rs.getString("function_name");
	                String definition = rs.getString("definition");

	                try (FileWriter writer = new FileWriter(envPath + "/functions/" + functionName + ".sql")) {
	                    writer.write(definition);
	                }
	            }
	        }
	    }
	    
	    private void exportViewScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String viewPath = envPath + "/views";
	        new File(viewPath).mkdirs();

	        String query = "SELECT table_name, view_definition FROM information_schema.views WHERE table_schema = ?";
	        try (Connection conn = dataSource.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {

	            stmt.setString(1, connInfo.getSchemaName());
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                String viewName = rs.getString("table_name");
	                String definition = rs.getString("view_definition");

	                try (FileWriter writer = new FileWriter(viewPath + "/" + viewName + ".sql")) {
	                    writer.write("CREATE OR REPLACE VIEW " + viewName + " AS\n" + definition + ";\n");
	                }
	            }
	        }
	    }

	    private void exportIndexScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String indexPath = envPath + "/indexes";
	        new File(indexPath).mkdirs();

	        String query = """
	            SELECT indexname, indexdef 
	            FROM pg_indexes 
	            WHERE schemaname = ?
	        """;

	        try (Connection conn = dataSource.getConnection();
	             PreparedStatement stmt = conn.prepareStatement(query)) {

	            stmt.setString(1, connInfo.getSchemaName());
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                String indexName = rs.getString("indexname");
	                String indexDef = rs.getString("indexdef");

	                try (FileWriter writer = new FileWriter(indexPath + "/" + indexName + ".sql")) {
	                    writer.write(indexDef + ";\n");
	                }
	            }
	        }
	    }

	    private void exportConstraintScripts(DataSource dataSource, DatabaseConnection connInfo, String envPath) throws Exception {
	        String constraintPath = envPath + "/constraints";
	        new File(constraintPath).mkdirs();

	        try (Connection conn = dataSource.getConnection()) {

	            // 1. Primary Keys
	            String pkQuery = """
	                SELECT 
	                    tc.constraint_name, kcu.table_name, kcu.column_name
	                FROM 
	                    information_schema.table_constraints tc
	                JOIN 
	                    information_schema.key_column_usage kcu 
	                    ON tc.constraint_name = kcu.constraint_name 
	                    AND tc.table_schema = kcu.table_schema
	                WHERE 
	                    tc.constraint_type = 'PRIMARY KEY' AND tc.table_schema = ?
	            """;

	            try (PreparedStatement stmt = conn.prepareStatement(pkQuery)) {
	                stmt.setString(1, connInfo.getSchemaName());
	                ResultSet rs = stmt.executeQuery();
	                while (rs.next()) {
	                    String table = rs.getString("table_name");
	                    String constraint = rs.getString("constraint_name");
	                    String column = rs.getString("column_name");

	                    String ddl = String.format(
	                        "ALTER TABLE %s ADD CONSTRAINT %s PRIMARY KEY (%s);",
	                        table, constraint, column
	                    );

	                    try (FileWriter writer = new FileWriter(constraintPath + "/" + constraint + ".sql")) {
	                        writer.write(ddl + "\n");
	                    }
	                }
	            }

	            // 2. Unique Constraints
	            String uniqueQuery = """
	                SELECT 
	                    tc.constraint_name, kcu.table_name, kcu.column_name
	                FROM 
	                    information_schema.table_constraints tc
	                JOIN 
	                    information_schema.key_column_usage kcu 
	                    ON tc.constraint_name = kcu.constraint_name 
	                    AND tc.table_schema = kcu.table_schema
	                WHERE 
	                    tc.constraint_type = 'UNIQUE' AND tc.table_schema = ?
	            """;

	            try (PreparedStatement stmt = conn.prepareStatement(uniqueQuery)) {
	                stmt.setString(1, connInfo.getSchemaName());
	                ResultSet rs = stmt.executeQuery();
	                while (rs.next()) {
	                    String table = rs.getString("table_name");
	                    String constraint = rs.getString("constraint_name");
	                    String column = rs.getString("column_name");

	                    String ddl = String.format(
	                        "ALTER TABLE %s ADD CONSTRAINT %s UNIQUE (%s);",
	                        table, constraint, column
	                    );

	                    try (FileWriter writer = new FileWriter(constraintPath + "/" + constraint + ".sql")) {
	                        writer.write(ddl + "\n");
	                    }
	                }
	            }

	            // 3. Foreign Keys (already present but improved formatting)
	            String fkQuery = """
	                SELECT
	                    tc.constraint_name, tc.table_name, kcu.column_name,
	                    ccu.table_name AS foreign_table_name,
	                    ccu.column_name AS foreign_column_name
	                FROM 
	                    information_schema.table_constraints AS tc 
	                JOIN 
	                    information_schema.key_column_usage AS kcu
	                    ON tc.constraint_name = kcu.constraint_name
	                    AND tc.table_schema = kcu.table_schema
	                JOIN 
	                    information_schema.constraint_column_usage AS ccu
	                    ON ccu.constraint_name = tc.constraint_name
	                    AND ccu.table_schema = tc.table_schema
	                WHERE 
	                    tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = ?
	            """;

	            try (PreparedStatement stmt = conn.prepareStatement(fkQuery)) {
	                stmt.setString(1, connInfo.getSchemaName());
	                ResultSet rs = stmt.executeQuery();
	                while (rs.next()) {
	                    String table = rs.getString("table_name");
	                    String constraint = rs.getString("constraint_name");
	                    String column = rs.getString("column_name");
	                    String refTable = rs.getString("foreign_table_name");
	                    String refColumn = rs.getString("foreign_column_name");

	                    String ddl = String.format(
	                        "ALTER TABLE %s ADD CONSTRAINT %s FOREIGN KEY (%s) REFERENCES %s(%s);",
	                        table, constraint, column, refTable, refColumn
	                    );

	                    try (FileWriter writer = new FileWriter(constraintPath + "/" + constraint + ".sql")) {
	                        writer.write(ddl + "\n");
	                    }
	                }
	            }

	        }
	    }


}
