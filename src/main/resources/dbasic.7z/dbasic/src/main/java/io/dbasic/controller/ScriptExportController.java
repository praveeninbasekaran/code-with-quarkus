package io.dbasic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.dbasic.service.ScriptExportService;

@RestController
@RequestMapping("/api/script")
public class ScriptExportController {
	  @Autowired
	    private ScriptExportService scriptExportService;

	  // Endpoint to trigger export for all types (tables, sequences, triggers)
	    @PostMapping("/export/{env}")
	    public ResponseEntity<String> exportSchemaScripts(@PathVariable("env") String env) {
	        String result = scriptExportService.exportSchemaScripts(env);
	        return ResponseEntity.ok(result);
	    }

	    // Health check or ping
	    @GetMapping("/status")
	    public ResponseEntity<String> status() {
	        return ResponseEntity.ok("✅ Script Exporter is running!");
	    }
}
