document.addEventListener("DOMContentLoaded", function () {
    new Chart(document.getElementById("doughnutChart"), {
        type: 'doughnut',
        data: {
            labels: ["Chrome", "IE", "Firefox"],
            datasets: [{ data: [30, 20, 50] }]
        }
    });
    new Chart(document.getElementById("barChart"), {
        type: 'bar',
        data: {
            labels: ["Jan", "Feb", "Mar"],
            datasets: [{
                label: "Electronics",
                data: [30, 50, 60],
                backgroundColor: "rgba(54, 162, 235, 0.5)"
            }]
        }
    });
});