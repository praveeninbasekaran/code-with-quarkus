package io.dbasic.model;

public class DatabaseConnection {

    private String envName;       // DEV, UAT, etc.
    private String dbType;        // POSTGRESQL, ORACLE, etc.
    private String host;
    private int port;
    private String dbName;
    private String username;
    private String password;
    private String schemaName;
	public String getEnvName() {
		return envName;
	}
	public void setEnvName(String envName) {
		this.envName = envName;
	}
	public String getDbType() {
		return dbType;
	}
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}
	public String getDbName() {
		return dbName;
	}
	public void setDbName(String dbName) {
		this.dbName = dbName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	@Override
	public String toString() {
		return "DatabaseConnection [envName=" + envName + ", dbType=" + dbType + ", host=" + host + ", port=" + port
				+ ", dbName=" + dbName + ", username=" + username + ", password=" + password + ", schemaName="
				+ schemaName + "]";
	}
	public DatabaseConnection(String envName, String dbType, String host, int port, String dbName, String username,
			String password, String schemaName) {
		this.envName = envName;
		this.dbType = dbType;
		this.host = host;
		this.port = port;
		this.dbName = dbName;
		this.username = username;
		this.password = password;
		this.schemaName = schemaName;
	}

	public DatabaseConnection() {
		// TODO Auto-generated constructor stub
	}

    
    
}
