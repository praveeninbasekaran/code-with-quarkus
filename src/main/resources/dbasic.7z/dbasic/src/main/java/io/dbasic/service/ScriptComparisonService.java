package io.dbasic.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import io.dbasic.dto.ScriptComparisonResult;
@Service
public class ScriptComparisonService {
	
	private static final String BASE_PATH = "src/main/resources/generated-scripts/";

    public List<ScriptComparisonResult> compareEnvScripts(String sourceEnv, String targetEnv, String objectType) {
        String sourceDir = BASE_PATH + sourceEnv.toLowerCase() + "/" + objectType.toLowerCase();
        String targetDir = BASE_PATH + targetEnv.toLowerCase() + "/" + objectType.toLowerCase();

        File srcFolder = new File(sourceDir);
        File tgtFolder = new File(targetDir);

        Map<String, String> sourceScripts = readScripts(srcFolder);
        Map<String, String> targetScripts = readScripts(tgtFolder);

        Set<String> allKeys = new HashSet<>();
        allKeys.addAll(sourceScripts.keySet());
        allKeys.addAll(targetScripts.keySet());

        List<ScriptComparisonResult> result = new ArrayList<>();

        for (String name : allKeys) {
            String srcScript = sourceScripts.get(name);
            String tgtScript = targetScripts.get(name);

            ScriptComparisonResult comp = new ScriptComparisonResult();
            comp.setObjectName(name);
            comp.setObjectType(objectType.toUpperCase());
            comp.setExistsInSource(srcScript != null);
            comp.setExistsInTarget(tgtScript != null);
            comp.setIsContentDifferent(srcScript != null && tgtScript != null && !srcScript.equals(tgtScript));
            comp.setSourceScript(srcScript);
            comp.setTargetScript(tgtScript);

            result.add(comp);
        }

        return result;
    }

    private Map<String, String> readScripts(File folder) {
        Map<String, String> map = new HashMap<>();
        if (!folder.exists() || !folder.isDirectory()) return map;

        for (File file : folder.listFiles((dir, name) -> name.endsWith(".sql"))) {
            try {
                String content = Files.readString(file.toPath());
                String name = file.getName().replace(".sql", "");
                map.put(name, content);
            } catch (IOException e) {
                throw new RuntimeException("Failed to read script file: " + file.getName(), e);
            }
        }
        return map;
    }
    
    public Map<String, List<ScriptComparisonResult>> compareAllEnvScripts(String sourceEnv, String targetEnv) {
        Map<String, List<ScriptComparisonResult>> allResults = new HashMap<>();

        String[] types = {"tables", "views", "sequences", "triggers", "constraints"};

        for (String type : types) {
            List<ScriptComparisonResult> result = compareEnvScripts(sourceEnv, targetEnv, type);
            allResults.put(type, result);
        }

        return allResults;
    }

    
}
