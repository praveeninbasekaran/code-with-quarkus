CREATE TABLE IF NOT EXISTS drm_sit.alert_dashboard_audit (
  alert_audit_id bigint NOT NULL,
  alert_id bigint,
  alert_name character varying,
  rule_id bigint,
  CONSTRAINT alert_dashboard_audit_pkey PRIMARY KEY (alert_audit_id)
);