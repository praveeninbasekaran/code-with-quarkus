package io.dbasic.utils;

public class TestAES {
	
	public static void main(String[] args) {
	    String encrypted = AESUtil.encrypt("asdfgh");
	    System.out.println("🛠️ Encrypted 'ad_sit': " + encrypted);
	}

}
