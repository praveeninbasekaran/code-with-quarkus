CREATE UNIQUE INDEX alert_dashboard_pkey ON drm_uat.alert_dashboard USING btree (alert_id);
