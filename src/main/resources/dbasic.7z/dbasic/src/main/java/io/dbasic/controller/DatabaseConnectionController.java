package io.dbasic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.dbasic.model.DatabaseConnection;
import io.dbasic.service.DatabaseConnectionExcelService;

@RestController
@RequestMapping("/api/connections")
public class DatabaseConnectionController {

	 @Autowired
	    private DatabaseConnectionExcelService excelService;

	    @GetMapping
	    public List<DatabaseConnection> getAllConnections() {
	        return excelService.readConnections();
	    }
	    @PostMapping
	    public String addConnection(@RequestBody DatabaseConnection connection) {
	        List<DatabaseConnection> existing = excelService.readConnections();
	        existing.add(connection);
	        excelService.writeConnections(existing);
	        return "Connection saved to Excel.";
	    }
}
