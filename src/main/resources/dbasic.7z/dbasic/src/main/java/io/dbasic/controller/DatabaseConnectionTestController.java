package io.dbasic.controller;

import java.sql.Connection;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.dbasic.service.DatabaseConnectionExcelService;
import io.dbasic.utils.DatabaseConnectionManager;

@RestController
@RequestMapping("/api/connections/test")
public class DatabaseConnectionTestController {

	 private final DatabaseConnectionExcelService excelService;

	    public DatabaseConnectionTestController(DatabaseConnectionExcelService excelService) {
	        this.excelService = excelService;
	    }
	    @GetMapping("/{envName}")
	    public ResponseEntity<String> testConnection(@PathVariable String envName) {
	        DatabaseConnectionManager manager = new DatabaseConnectionManager(excelService);

	        try (Connection conn = manager.getConnectionForEnv(envName)) {
	            if (conn != null && !conn.isClosed()) {
	                return ResponseEntity.ok("✅ Connection successful to " + envName);
	            } else {
	                return ResponseEntity.status(500).body("❌ Connection is null or closed");
	            }
	        } catch (Exception e) {
	        	e.printStackTrace();
	            return ResponseEntity.status(500).body("❌ Connection failed: " + e.getMessage());
	        }
	    }
}
