package io.dbasic.dto;

public class TableInfo {

	private String tableName;
	private String columnName;
	private String dataType;
	private String isNullable;
	private String columnDefault;
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public String getIsNullable() {
		return isNullable;
	}
	public void setIsNullable(String isNullable) {
		this.isNullable = isNullable;
	}
	public String getColumnDefault() {
		return columnDefault;
	}
	public void setColumnDefault(String columnDefault) {
		this.columnDefault = columnDefault;
	}
	@Override
	public String toString() {
		return "TableInfo [tableName=" + tableName + ", columnName=" + columnName + ", dataType=" + dataType
				+ ", isNullable=" + isNullable + ", columnDefault=" + columnDefault + "]";
	}
	public TableInfo(String tableName, String columnName, String dataType, String isNullable, String columnDefault) {
		
		this.tableName = tableName;
		this.columnName = columnName;
		this.dataType = dataType;
		this.isNullable = isNullable;
		this.columnDefault = columnDefault;
	}

	public TableInfo() {
		// TODO Auto-generated constructor stub
	}
	
}
