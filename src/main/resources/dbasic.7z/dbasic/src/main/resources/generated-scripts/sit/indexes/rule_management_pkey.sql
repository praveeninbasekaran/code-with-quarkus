CREATE UNIQUE INDEX rule_management_pkey ON drm_sit.rule_management USING btree (rule_id);
