package io.dbasic.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.dbasic.dto.SchemaOverviewResponse;
import io.dbasic.dto.TableInfo;
import io.dbasic.excel.ExcelSchemaWriter;
import io.dbasic.model.DatabaseConnection;
import io.dbasic.service.DatabaseConnectionExcelService;
import io.dbasic.service.SchemaExplorerService;

@RestController
@RequestMapping("/api/schema")
public class SchemaExplorerController {

	@Autowired
	private SchemaExplorerService schemaService;

	@Autowired
	private DatabaseConnectionExcelService connectionExcelService;

	@GetMapping("/snapshot/{envName}")
	public String generateSchemaSnapshot(@PathVariable String envName) {
		// load connection from Excel based on env name
		List<DatabaseConnection> conns = connectionExcelService.readConnections();

		DatabaseConnection conn = conns.stream().filter(c -> c.getEnvName().equalsIgnoreCase(envName)).findFirst()
				.orElseThrow(() -> new RuntimeException("Connection not found"));

		List<TableInfo> tableInfos = schemaService.getTableMetadata(conn);
		String filePath = "src/main/resources/data/schema_snapshot_" + conn.getEnvName().toLowerCase() + ".xlsx";

		ExcelSchemaWriter.writeTableInfoToExcel(tableInfos, filePath);
		return "Snapshot created at: " + filePath;
	}

	@GetMapping("/{env}")
	public SchemaOverviewResponse getSchemaObjects(@PathVariable String env) {
		return schemaService.getSchemaObjects(env);
	}
}
