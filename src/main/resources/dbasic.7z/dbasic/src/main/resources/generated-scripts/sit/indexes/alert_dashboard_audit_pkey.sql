CREATE UNIQUE INDEX alert_dashboard_audit_pkey ON drm_sit.alert_dashboard_audit USING btree (alert_audit_id);
