package io.dbasic.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Optional;

import io.dbasic.model.DatabaseConnection;
import io.dbasic.service.DatabaseConnectionExcelService;

public class DatabaseConnectionManager {
	
	 private final DatabaseConnectionExcelService excelService;

	    public DatabaseConnectionManager(DatabaseConnectionExcelService excelService) {
	        this.excelService = excelService;
	    }
	    public Connection getConnectionForEnv(String envName) {
	        Optional<DatabaseConnection> connectionOpt = excelService.readConnections().stream()
	                .filter(conn -> conn.getEnvName().equalsIgnoreCase(envName))
	                .findFirst();

	        if (connectionOpt.isEmpty()) {
	            throw new RuntimeException("No DB connection found for environment: " + envName);
	        }

	        DatabaseConnection conn = connectionOpt.get();
	        System.out.println("🔐 Decrypting password for env: " + conn.getEnvName());
	        System.out.println("🔐 Encrypted value: " + conn.getPassword());
	        String decryptedPassword = AESUtil.decrypt(conn.getPassword());

	        try {
	            String jdbcUrl = buildJdbcUrl(conn);
	            return DriverManager.getConnection(jdbcUrl, conn.getUsername(), decryptedPassword);
	        } catch (Exception e) {
	            throw new RuntimeException("Failed to connect to DB for " + envName, e);
	        }
	    }

	    private String buildJdbcUrl(DatabaseConnection conn) {
	        return switch (conn.getDbType().toLowerCase()) {
	            case "postgres", "postgresql" ->
	                "jdbc:postgresql://" + conn.getHost() + ":" + conn.getPort() + "/" + conn.getDbName();
	            case "mysql" ->
	                "jdbc:mysql://" + conn.getHost() + ":" + conn.getPort() + "/" + conn.getDbName();
	            case "oracle" ->
	                "jdbc:oracle:thin:@" + conn.getHost() + ":" + conn.getPort() + ":" + conn.getDbName();
	            default ->
	                throw new RuntimeException("Unsupported DB type: " + conn.getDbType());
	        };
	    }
	    
	    public static Connection createConnection(DatabaseConnection conn) {
	        try {
	            String decryptedPassword = AESUtil.decrypt(conn.getPassword());
	            String jdbcUrl = new DatabaseConnectionManager(null).buildJdbcUrl(conn);
	            return DriverManager.getConnection(jdbcUrl, conn.getUsername(), decryptedPassword);
	        } catch (Exception e) {
	            throw new RuntimeException("Failed to connect with direct DBConnection object", e);
	        }
	    }

}
