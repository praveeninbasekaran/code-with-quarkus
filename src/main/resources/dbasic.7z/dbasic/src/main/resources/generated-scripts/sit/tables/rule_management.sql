CREATE TABLE IF NOT EXISTS drm_sit.rule_management (
  rule_id bigint NOT NULL,
  rule_name character varying,
  CONSTRAINT rule_management_pkey PRIMARY KEY (rule_id)
);