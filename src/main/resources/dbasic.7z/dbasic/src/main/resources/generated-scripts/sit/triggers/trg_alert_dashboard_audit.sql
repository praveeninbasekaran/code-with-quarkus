-- Trigger
CREATE TRIGGER trg_alert_dashboard_audit
AFTER UPDATE ON alert_dashboard
FOR EACH ROW
EXECUTE FUNCTION drm_sit.fn_alert_dashboard_audit();

-- Function used in trigger
CREATE OR REPLACE FUNCTION drm_sit.fn_alert_dashboard_audit()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    -- For INSERT or UPDATE, log NEW row
    IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') THEN
        INSERT INTO drm_sit.alert_dashboard_audit (
            alert_audit_id,
            alert_id,
            alert_name,
            rule_id
        )
        VALUES (
            nextval('drm_sit.alert_dashboard_audit_alert_audit_id_seq'),
            NEW.alert_id,
            NEW.alert_name,
            NEW.rule_id
        );

    -- For DELETE, log OLD row
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO drm_sit.alert_dashboard_audit (
            alert_audit_id,
            alert_id,
            alert_name,
            rule_id
        )
        VALUES (
            nextval('drm_sit.alert_dashboard_audit_alert_audit_id_seq'),
            OLD.alert_id,
            OLD.alert_name,
            OLD.rule_id
        );
    END IF;

    RETURN NULL;
END;
$function$
