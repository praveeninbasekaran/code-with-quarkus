package io.dbasic.excel;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import io.dbasic.dto.TableInfo;

public class ExcelSchemaWriter {

	public static void writeTableInfoToExcel(List<TableInfo> tables, String filePath) {
        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Tables");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("Table Name");
            header.createCell(1).setCellValue("Column Name");
            header.createCell(2).setCellValue("Data Type");
            header.createCell(3).setCellValue("Nullable");
            header.createCell(4).setCellValue("Default");

            int rowNum = 1;
            for (TableInfo t : tables) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(t.getTableName());
                row.createCell(1).setCellValue(t.getColumnName());
                row.createCell(2).setCellValue(t.getDataType());
                row.createCell(3).setCellValue(t.getIsNullable());
                row.createCell(4).setCellValue(t.getColumnDefault());
            }

            FileOutputStream out = new FileOutputStream(filePath);
            workbook.write(out);
        } catch (Exception e) {
            throw new RuntimeException("Failed to write Excel", e);
        }
    }
}
