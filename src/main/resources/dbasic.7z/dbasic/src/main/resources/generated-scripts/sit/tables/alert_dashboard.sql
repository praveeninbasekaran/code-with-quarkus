CREATE TABLE IF NOT EXISTS drm_sit.alert_dashboard (
  alert_id bigint NOT NULL,
  alert_name character varying,
  rule_id bigint,
  CONSTRAINT alert_dashboard_pkey PRIMARY KEY (alert_id)
);