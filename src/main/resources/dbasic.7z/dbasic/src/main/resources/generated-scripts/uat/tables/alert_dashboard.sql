CREATE TABLE IF NOT EXISTS drm_uat.alert_dashboard (
  alert_id bigint NOT NULL,
  alert_name character varying,
  CONSTRAINT alert_dashboard_pkey PRIMARY KEY (alert_id)
);