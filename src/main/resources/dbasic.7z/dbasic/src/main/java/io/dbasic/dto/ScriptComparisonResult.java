package io.dbasic.dto;

import java.util.Map;

public class ScriptComparisonResult {

	private String objectName;
	private String objectType;
	private boolean existsInSource;
	private boolean existsInTarget;
	private boolean isContentDifferent;
	private String sourceScript;
	private String targetScript;
	private Map<String, String> sequenceDifferences;
	private Map<String, String> triggerDifferences;
	private Map<String, String> viewDifferences;
	private Map<String, String> constraintDifferences;
	
	
	@Override
	public String toString() {
		return "ScriptComparisonResult [objectName=" + objectName + ", objectType=" + objectType + ", existsInSource="
				+ existsInSource + ", existsInTarget=" + existsInTarget + ", isContentDifferent=" + isContentDifferent
				+ ", sourceScript=" + sourceScript + ", targetScript=" + targetScript + ", sequenceDifferences="
				+ sequenceDifferences + ", triggerDifferences=" + triggerDifferences + ", viewDifferences="
				+ viewDifferences + ", constraintDifferences=" + constraintDifferences + "]";
	}
	public Map<String, String> getSequenceDifferences() {
		return sequenceDifferences;
	}
	public void setSequenceDifferences(Map<String, String> sequenceDifferences) {
		this.sequenceDifferences = sequenceDifferences;
	}
	public Map<String, String> getTriggerDifferences() {
		return triggerDifferences;
	}
	public void setTriggerDifferences(Map<String, String> triggerDifferences) {
		this.triggerDifferences = triggerDifferences;
	}
	public Map<String, String> getViewDifferences() {
		return viewDifferences;
	}
	public void setViewDifferences(Map<String, String> viewDifferences) {
		this.viewDifferences = viewDifferences;
	}
	public Map<String, String> getConstraintDifferences() {
		return constraintDifferences;
	}
	public void setConstraintDifferences(Map<String, String> constraintDifferences) {
		this.constraintDifferences = constraintDifferences;
	}
	public void setContentDifferent(boolean isContentDifferent) {
		this.isContentDifferent = isContentDifferent;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}
	public boolean isExistsInSource() {
		return existsInSource;
	}
	public void setExistsInSource(boolean existsInSource) {
		this.existsInSource = existsInSource;
	}
	public boolean isExistsInTarget() {
		return existsInTarget;
	}
	public void setExistsInTarget(boolean existsInTarget) {
		this.existsInTarget = existsInTarget;
	}
	public boolean isContentDifferent() {
		return isContentDifferent;
	}
	public void setIsContentDifferent(boolean isContentDifferent) {
		this.isContentDifferent = isContentDifferent;
	}
	public String getSourceScript() {
		return sourceScript;
	}
	public void setSourceScript(String sourceScript) {
		this.sourceScript = sourceScript;
	}
	public String getTargetScript() {
		return targetScript;
	}
	public void setTargetScript(String targetScript) {
		this.targetScript = targetScript;
	}
	
	public ScriptComparisonResult(String objectName, String objectType, boolean existsInSource, boolean existsInTarget,
			boolean isContentDifferent, String sourceScript, String targetScript,
			Map<String, String> sequenceDifferences, Map<String, String> triggerDifferences,
			Map<String, String> viewDifferences, Map<String, String> constraintDifferences) {
		this.objectName = objectName;
		this.objectType = objectType;
		this.existsInSource = existsInSource;
		this.existsInTarget = existsInTarget;
		this.isContentDifferent = isContentDifferent;
		this.sourceScript = sourceScript;
		this.targetScript = targetScript;
		this.sequenceDifferences = sequenceDifferences;
		this.triggerDifferences = triggerDifferences;
		this.viewDifferences = viewDifferences;
		this.constraintDifferences = constraintDifferences;
	}
	public ScriptComparisonResult() {
	}



}
