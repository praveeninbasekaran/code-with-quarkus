package io.dbasic.dto;

import java.util.List;

import io.dbasic.model.SchemaObject;

public class SchemaOverviewResponse {
	private List<SchemaObject> tables;
    private List<SchemaObject> sequences;
    private List<SchemaObject> triggers;

    public SchemaOverviewResponse(List<SchemaObject> tables, List<SchemaObject> sequences, List<SchemaObject> triggers) {
        this.tables = tables;
        this.sequences = sequences;
        this.triggers = triggers;
    }

    public List<SchemaObject> getTables() {
        return tables;
    }

    public List<SchemaObject> getSequences() {
        return sequences;
    }

    public List<SchemaObject> getTriggers() {
        return triggers;
    }

    public void setTables(List<SchemaObject> tables) {
        this.tables = tables;
    }

    public void setSequences(List<SchemaObject> sequences) {
        this.sequences = sequences;
    }

    public void setTriggers(List<SchemaObject> triggers) {
        this.triggers = triggers;
    }
}
