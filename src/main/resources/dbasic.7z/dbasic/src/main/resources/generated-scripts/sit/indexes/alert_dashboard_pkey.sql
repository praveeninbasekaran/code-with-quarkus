CREATE UNIQUE INDEX alert_dashboard_pkey ON drm_sit.alert_dashboard USING btree (alert_id);
