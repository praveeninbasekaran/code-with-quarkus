package io.dbasic.service;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.dbasic.dto.SchemaOverviewResponse;
import io.dbasic.dto.TableInfo;
import io.dbasic.model.DatabaseConnection;
import io.dbasic.model.SchemaObject;
import io.dbasic.utils.DatabaseConnectionManager;

@Service
public class SchemaExplorerService {
	
	@Autowired
	private DatabaseConnectionExcelService excelService;
	 	
	 public List<TableInfo> getTableMetadata(DatabaseConnection conn) {
	        List<TableInfo> tables = new ArrayList<>();
	        try (Connection connection = DatabaseConnectionManager.createConnection(conn)) {

	            DatabaseMetaData metaData = connection.getMetaData();
	            ResultSet columns = metaData.getColumns(null, conn.getSchemaName(), "%", "%");

	            while (columns.next()) {
	                TableInfo info = new TableInfo();
	                info.setTableName(columns.getString("TABLE_NAME"));
	                info.setColumnName(columns.getString("COLUMN_NAME"));
	                info.setDataType(columns.getString("TYPE_NAME"));
	                info.setIsNullable(columns.getString("IS_NULLABLE"));
	                info.setColumnDefault(columns.getString("COLUMN_DEF"));
	                tables.add(info);
	            }

	        } catch (Exception ex) {
	            throw new RuntimeException("Failed to load schema", ex);
	        }

	        return tables;
	    }
	 
	 public void testConnection() {
		    DatabaseConnectionManager manager = new DatabaseConnectionManager(excelService);
		    try (Connection conn = manager.getConnectionForEnv("DEV")) {
		        System.out.println("✅ Connection successful!");
		    } catch (Exception e) {
		        e.printStackTrace();
		    }
		}

	 public SchemaOverviewResponse getSchemaObjects(String envName) {
		    List<SchemaObject> tables = new ArrayList<>();
		    List<SchemaObject> sequences = new ArrayList<>();
		    List<SchemaObject> triggers = new ArrayList<>();

		    try {
		        DatabaseConnection connInfo = excelService.readConnections()
		                .stream()
		                .filter(c -> c.getEnvName().equalsIgnoreCase(envName))
		                .findFirst()
		                .orElseThrow(() -> new RuntimeException("No DB config for env: " + envName));

		        try (Connection conn = DatabaseConnectionManager.createConnection(connInfo);
		             Statement stmt = conn.createStatement()) {

		            // Tables
		            ResultSet rsTables = stmt.executeQuery(
		                "SELECT table_name FROM information_schema.tables WHERE table_schema = '" + connInfo.getSchemaName() + "'");
		            while (rsTables.next()) {
		                tables.add(new SchemaObject(rsTables.getString("table_name"), "TABLE"));
		            }

		            // Sequences
		            ResultSet rsSeq = stmt.executeQuery(
		                "SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = '" + connInfo.getSchemaName() + "'");
		            while (rsSeq.next()) {
		                sequences.add(new SchemaObject(rsSeq.getString("sequence_name"), "SEQUENCE"));
		            }

		            
		            // Triggers (deduplicated)
		            Set<String> seenTriggers = new HashSet<>();
		            ResultSet rsTrig = stmt.executeQuery(
		                "SELECT trigger_name FROM information_schema.triggers WHERE trigger_schema = '" + connInfo.getSchemaName() + "'");
		            while (rsTrig.next()) {
		                String triggerName = rsTrig.getString("trigger_name");
		                if (seenTriggers.add(triggerName)) {
		                    triggers.add(new SchemaObject(triggerName, "TRIGGER"));
		                }
		            }	

		        }

		    } catch (Exception e) {
		        throw new RuntimeException("❌ Failed to retrieve schema objects for env: " + envName, e);
		    }

		    return new SchemaOverviewResponse(tables, sequences, triggers);
		}


}
