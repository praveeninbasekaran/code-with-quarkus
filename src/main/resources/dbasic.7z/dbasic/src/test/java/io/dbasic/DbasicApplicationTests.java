package io.dbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
